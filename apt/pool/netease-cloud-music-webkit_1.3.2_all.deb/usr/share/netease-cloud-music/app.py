#!/usr/bin/python3
"""An independent GTK/WebKitGTK window for NetEase Cloud Music."""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import weakref
from urllib.parse import urlsplit

APP_ID = "io.github.neteasecloudmusic.WebPlayer"
APP_NAME = "网易云音乐"
VERSION = "1.3.2"
HOME_URL = "https://music.163.com/st/webplayer"
STORAGE_NAME = "netease-cloud-music"
PLAYBACK_LOG_LIMIT = 2 * 1024 * 1024
CACHE_SETTINGS_WORLD = "MusicCacheSettings"
WINDOW_INTERACTION_WORLD = "MusicWindowInteraction"
WINDOW_BUTTON_SIZE = 26
WINDOW_BUTTON_PITCH = 30
WINDOW_BUTTON_END = 16
WINDOW_BUTTON_SPACING = WINDOW_BUTTON_PITCH - WINDOW_BUTTON_SIZE
WINDOW_CORNER_RADIUS = 16
# The centre of the last web button is half a slot before the right padding.
WINDOW_BUTTON_RESERVE = WINDOW_BUTTON_END + 3 * WINDOW_BUTTON_PITCH - WINDOW_BUTTON_SPACING / 2
WINDOW_DEFAULT_SIZE = (1080, 720)
WINDOW_MIN_SIZE = (800, 540)
VIEWPORT_MIN_SIZE = (480, 320)
COMPACT_WIDTH = 540
COMPACT_BUTTON_CENTER = 22
COMPACT_HEADER_INSET = COMPACT_BUTTON_CENTER + WINDOW_BUTTON_SIZE / 2 + 6
PLAYER_LAYOUT = """
section[class*="RightContainer_"] { flex: 1 1 0 !important; min-width: 0 !important; width: auto !important; }
#page_pc_main_nav {
    box-sizing: border-box !important;
    padding-right: var(--music-window-controls-width) !important;
}
#page_pc_main_nav [class*="HeaderRow_"] > [class*="HistoryIconBackground_"] {
    margin-right: 8px !important;
}
#page_pc_main_nav [class*="MiniModeIconBar_"] > :not(:empty):not([hidden]):not([style*="display: none"]) {
    display: flex !important;
    align-items: center;
    justify-content: center;
    flex: 0 0 var(--music-window-button-pitch) !important;
    width: var(--music-window-button-pitch) !important;
    margin: 0 !important;
}
#page_pc_main_nav [class*="MiniModeIconBar_"] .icon { max-width: var(--music-window-button-pitch); }
#topArea > .title { min-width: 0; }
#topArea > .title > svg {
    display: block !important;
    height: 22px !important;
    max-width: 100%;
    overflow: visible;
}
/* The fixed comment backdrop covers the playlist cover and sidebar in WebKit. */
#page_pc_songlist_commentflow > [class*="Mask_"] > [class*="StyledStickyMask_"] {
    display: none !important;
}
#page_pc_setting #play {
    --music-setting-font-size: 13px;
    --music-setting-line-height: 20px;
    --music-setting-label-width: 7em;
    --music-setting-option-height: 24px;
    --music-setting-option-gap: 8px 16px;
    --music-setting-section-gap: 18px;
    padding-top: 22px !important;
    padding-bottom: 22px !important;
}
#page_pc_setting #play > .play > * { margin-top: 0 !important; margin-bottom: var(--music-setting-section-gap) !important; }
#page_pc_setting #play > .play > :last-child { margin-bottom: 0 !important; }

@media (max-width: 1200px) {
    #page_pc_main_nav { padding-left: clamp(12px, 2vw, 40px) !important; }
    #page_pc_main_nav [class*="HeaderRow_"] { display: flex !important; align-items: center; min-width: 0; }
    #page_pc_main_nav [class*="HeaderRow_"] > :empty { display: none !important; }
    #page_pc_main_nav [class*="HistoryIconBackground_"] { flex: none; }
    #page_pc_main_nav [class*="SearchWrapper_"] { flex: 0 1 258px; min-width: 48px; }
    #page_pc_main_nav .searchbox { width: 100% !important; min-width: 0 !important; }
    #page_pc_main_nav .searchbox input { min-width: 0 !important; }
    #page_pc_main_nav [class*="Bar_b2jgnke"] { flex: 0 2 auto; min-width: 60px; margin: 0 8px 0 auto !important; }
    #page_pc_main_nav [class*="Bar_b2jgnke"] > * { min-width: 0; }
    #page_pc_main_nav [class*="Bar_b2jgnke"] > :first-child,
    #page_pc_main_nav [class*="Bar_b2jgnke"] > :last-child { flex: none; }
    #page_pc_main_nav [class*="Bar_b2jgnke"] > :nth-child(3):not(:last-child) { overflow: hidden; }
    #page_pc_main_nav [class*="Name_"] { max-width: 120px; }
    #page_pc_setting section[id] > :not(h3) { flex: 1 1 auto; min-width: 0; max-width: 100%; }
    #page_pc_setting .option { flex-wrap: wrap; }
    #page_pc_setting .option > .option-item { margin: 4px 0 4px 16px !important; }
    #page_pc_setting .web-about .link { display: inline-block; line-height: 1.6; }
}

@media (max-width: 820px) {
    #page_pc_main_nav [class*="Bar_b2jgnke"] { min-width: 56px; }
    #page_pc_main_nav [class*="Bar_b2jgnke"] > :nth-child(3):not(:last-child) { display: none !important; }
    #page_pc_setting { padding-left: 16px !important; padding-right: 16px !important; }
    #page_pc_setting section[id] { flex-direction: column !important; }
    #page_pc_setting section[id] > h3 { width: auto !important; margin-bottom: 12px !important; }
    #page_pc_setting .cmd-anchor-link-wrapper { flex-wrap: wrap; }
}

@media (max-width: 720px) {
    [class*="Container_c1udi5wp"] { min-width: 0 !important; width: clamp(100px, 25vw, 180px); }
    [class*="Container_c1udi5wp"] > [class*="BackContainer_"] { width: 100% !important; }

    #page_pc_mini_bar [class*="BarWrapper_"] {
        display: grid !important;
        grid-template-columns: minmax(0, 1fr) auto;
        min-height: 80px;
        height: auto !important;
        padding: 4px 12px !important;
    }
    #page_pc_mini_bar [class*="BarWrapper_"] .side,
    #page_pc_mini_bar [class*="BarWrapper_"] .left,
    #page_pc_mini_bar [class*="BarWrapper_"] .right {
        width: auto !important;
        min-width: 0;
        height: auto !important;
    }
    #page_pc_mini_bar [class*="BarWrapper_"] .middle {
        grid-column: 1 / -1;
        grid-row: 2;
        width: 100% !important;
        min-width: 0;
    }
    #page_pc_mini_bar [class*="DefaultBarWrapper_"] .middle .btns { padding-top: 0 !important; }
    #page_pc_mini_bar .vinyl-page-bar-wrapper .middle { height: 40px !important; }
    #page_pc_mini_bar .vinyl-page-bar-wrapper .left { flex-wrap: wrap; }
    #page_pc_mini_bar .right-side .right { flex-wrap: wrap; justify-content: flex-end; }

    [class*="VinylPageLayoutContainer_"] {
        flex-direction: column;
        overflow-y: auto;
        box-sizing: border-box;
        padding: 48px 12px 94px;
    }
    [class*="VinylPageLayoutContainer_"] > .side,
    [class*="VinylPageLayoutContainer_"] > .center { display: none; }
    [class*="VinylPageLayoutContainer_"] > .vinyl { flex: none; max-width: 100%; }
    [class*="VinylPageLayoutContainer_"] > .display {
        flex: none;
        width: 100% !important;
        min-height: 200px;
        height: auto !important;
        padding: 12px 0 !important;
    }
}

@media (max-width: 540px) {
    #page_pc_main_nav {
        flex: none;
        height: auto !important;
        padding: var(--music-window-compact-inset) 10px 8px !important;
    }
    #page_pc_main_nav [class*="HeaderRow_"] { flex-wrap: wrap; row-gap: 4px; }
    #page_pc_main_nav [class*="SearchWrapper_"] { flex: 1 1 96px; }
    #page_pc_main_nav [class*="IconBar_"] { height: auto; }
    [class*="LeftScrollContainer_"] .draggable { padding-left: 6px !important; }
    [class*="AppScrollContainer_"] { overflow-x: auto !important; }
}
"""

if sys.version_info < (3, 8):
    print("需要 Python 3.8 或更新版本。", file=sys.stderr)
    sys.exit(1)

# Choose the display backend before GTK is imported. The parent process may
# force GDK_BACKEND=x11 even on a Wayland desktop; that adds an XWayland path.
# This override is local to this application, with X11 as an automatic fallback.
display_backend = os.environ.get("NETEASE_MUSIC_BACKEND", "")
if display_backend in ("wayland", "x11"):
    os.environ["GDK_BACKEND"] = display_backend
elif os.environ.get("XDG_SESSION_TYPE") == "wayland" and os.environ.get("WAYLAND_DISPLAY"):
    os.environ["GDK_BACKEND"] = "wayland,x11"

try:
    import cairo
    import gi
    gi.require_foreign("cairo")
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    gi.require_version("Gst", "1.0")
    WEBKIT_API = None
    for api in ("4.1", "4.0"):
        try:
            gi.require_version("WebKit2", api)
        except ValueError:
            continue
        WEBKIT_API = api
        break
    if WEBKIT_API is None:
        raise ValueError("未安装 WebKit2 4.1 或 4.0 的运行组件")
    # Choose one ABI before importing it; Soup 2 and Soup 3 cannot share a process.
    from gi.repository import Gdk, Gio, GLib, Gtk, WebKit2
except (ImportError, ValueError) as exc:
    print("缺少运行组件。请通过 sudo apt install ./软件包.deb 安装完整依赖，\n"
          "或在源码目录运行 bash install-dependencies.sh。\n"
          "WebKit 组件优先使用 gir1.2-webkit2-4.1；较旧软件源可使用 gir1.2-webkit2-4.0。\n"
          f"详细信息：{exc}", file=sys.stderr)
    sys.exit(1)

from media_service import MediaService
from audio_buffer import delivery_script
from audio_cache import AudioCache
from music_downloads import FORMATS, MusicDownloads, downloaded_songs, load_preferences, resource_id
from quality_service import QualityService
from stream_player import StreamPlayer, transition_settings

if (Gtk.MAJOR_VERSION, Gtk.MINOR_VERSION) < (3, 24):
    print("需要 GTK 3.24 或更新的 GTK 3 版本。", file=sys.stderr)
    sys.exit(1)
if (WebKit2.get_major_version(), WebKit2.get_minor_version()) < (2, 28):
    print("需要 WebKitGTK 2.28 或更新版本。", file=sys.stderr)
    sys.exit(1)


def private_directory(base, fallback):
    candidate = Path(os.environ.get(base) or Path.home() / fallback)
    if not candidate.is_absolute():
        candidate = Path.home() / fallback
    path = candidate / STORAGE_NAME
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    path.chmod(0o700)
    return path


def opening_window_geometry(state, available):
    # Leave room around the window, including on displays smaller than the usual minimum.
    limits = tuple(max(1, length * 85 // 100) for length in available)
    minimum = tuple(min(size, limit) for size, limit in zip(WINDOW_MIN_SIZE, limits))
    saved = {} if state.get("maximized") else state
    size = []
    for key, default, low, high in zip(("width", "height"), WINDOW_DEFAULT_SIZE, minimum, limits):
        value = saved.get(key, default)
        if not isinstance(value, (int, float)) or (isinstance(value, float) and not math.isfinite(value)):
            value = default
        size.append(int(max(low, min(high, value))))
    return minimum, tuple(size)


def fit_page_zoom(preferred, size, scale):
    limit = min(length / (minimum * scale) for length, minimum in zip(size, VIEWPORT_MIN_SIZE))
    # Small steps prevent recreating the page layout for every pixel of a drag.
    return max(0.5, min(preferred, math.floor(20 * limit + 0.001) / 20))


def configure_direct_connection(manager, context):
    # WebKitGTK 2.28/2.30 expose this setting on the context.
    target = manager if hasattr(manager, "set_network_proxy_settings") else context
    settings = WebKit2.NetworkProxySettings.new(None, ["*"])
    target.set_network_proxy_settings(WebKit2.NetworkProxyMode.CUSTOM, settings)


def supported_uri(uri):
    """Remote content never launches a browser, shell or local protocol handler."""
    try:
        parsed = urlsplit(uri)
        return parsed.scheme in ("https", "http") and bool(parsed.hostname)
    except ValueError:
        return False


def is_player_uri(uri):
    try:
        parsed = urlsplit(uri or "")
        return (parsed.scheme == "https" and parsed.hostname == "music.163.com"
                and parsed.path.rstrip("/") == "/st/webplayer")
    except ValueError:
        return False


def is_music_uri(uri):
    try:
        parsed = urlsplit(uri or "")
        return parsed.scheme == "https" and parsed.hostname == "music.163.com"
    except ValueError:
        return False


def is_login_uri(uri):
    if not is_music_uri(uri):
        return False
    try:
        parsed = urlsplit(uri)
        routes = (parsed.path, urlsplit(parsed.fragment).path)
        return any(route.rstrip("/") == "/login" for route in routes)
    except ValueError:
        return False


def login_cookie_fingerprint(cookies):
    # Keep only an in-memory digest to distinguish a new login from routine
    # cookie updates, including replacement of a stale authentication cookie.
    values = sorted(cookie.get_value() for cookie in cookies
                    if cookie.get_name() == "MUSIC_U" and cookie.get_value())
    if not values:
        return b""
    return hashlib.sha256(json.dumps(values).encode("utf-8")).digest()


def page_response_error(response):
    status = response.get_status_code()
    mime = response.get_mime_type() or "未知"
    headers = response.get_http_headers()
    declared_type = headers.get_one("Content-Type") if headers else None
    disposition = headers.get_one("Content-Disposition") if headers else None
    return ("播放器首页没有返回可显示的网页。\n"
            f"HTTP 状态：{status}；WebKit 内容类型：{mime}\n"
            f"Content-Type：{declared_type or '未提供'}\n"
            f"Content-Disposition：{disposition or '未提供'}\n"
            "请稍后重试；若持续出现，请提供以上响应信息。")


def create_webview(context, related_view=None):
    properties = {"related_view": related_view} if related_view else {"web_context": context}
    if hasattr(WebKit2, "WebsitePolicies"):
        # Music continues across asynchronous URL requests and track changes.
        properties["website_policies"] = WebKit2.WebsitePolicies(
            autoplay=WebKit2.AutoplayPolicy.ALLOW)
    return WebKit2.WebView(**properties)


class MusicApplication(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.main_window = None

    def do_startup(self):
        Gtk.Application.do_startup(self)
        GLib.set_application_name(APP_NAME)
        GLib.set_prgname(APP_ID)
        self.data_dir = private_directory("XDG_DATA_HOME", ".local/share")
        self.cache_dir = private_directory("XDG_CACHE_HOME", ".cache")
        self.config_dir = private_directory("XDG_CONFIG_HOME", ".config")
        self.default_audio_cache_directory = self.cache_dir / "audio"
        self.audio_cache_config = self.config_dir / "audio-cache.json"
        self.audio_cache_directory = self.load_audio_cache_directory()
        self.download_config = self.config_dir / "downloads.json"
        downloads = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD)
        self.default_download_directory = (Path(downloads) if downloads else Path.home() / "Downloads") / APP_NAME
        self.download_directory, self.download_format = load_preferences(
            self.download_config, self.default_download_directory)
        self.transition_config = self.config_dir / "playback-transition.json"
        self.transition = self.load_transition()
        self.state_path = self.config_dir / "window.json"
        self.state = {}
        try:
            saved = json.loads(self.state_path.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                self.state = saved
        except (OSError, ValueError):
            pass
        self.create_web_context()
        self.system_media = MediaService(
            self.get_dbus_connection(), APP_ID, APP_NAME, STORAGE_NAME,
            self.media_control, self.do_activate, self.quit)
        icon = Path(__file__).resolve().parent / "assets" / "netease-cloud-music.svg"
        Gtk.IconTheme.get_default().append_search_path(str(icon.parent))
        if icon.exists():
            try:
                Gtk.Window.set_default_icon_from_file(str(icon))
            except GLib.Error as exc:
                print(f"无法读取应用图标，请确认已安装 librsvg2-common：{exc.message}", file=sys.stderr)
        self.add_action_callback("quit", lambda *_: self.quit())
        self.set_accels_for_action("app.quit", ["<Primary>q"])
        self.add_action_callback("recover", self.recover_player)
        self.set_accels_for_action("app.recover", ["<Primary><Shift>r"])

    def create_web_context(self):
        self.manager = WebKit2.WebsiteDataManager(
            base_data_directory=str(self.data_dir / "webkit"),
            base_cache_directory=str(self.cache_dir / "webkit"))
        self.manager.get_cookie_manager().set_persistent_storage(
            str(self.data_dir / "cookies.sqlite"), WebKit2.CookiePersistentStorage.SQLITE)
        self.context = WebKit2.WebContext.new_with_website_data_manager(self.manager)
        self.context.set_sandbox_enabled(True)
        configure_direct_connection(self.manager, self.context)
        self.context.connect("download-started", self.on_download)
        self.start_login_watch()

    def recover_player(self, *_):
        if getattr(self, "_recovering_player", False) or self.main_window is None:
            return
        self._recovering_player = True
        self.hold()
        try:
            maximized = self.main_window.is_maximized()
            self.system_media.reset()
            self.save_state(self.main_window)
            self.stop_login_watch()
            # A page reload keeps the same network session and media process.
            # Replace both while retaining their persistent data directories.
            for window in list(self.get_windows()):
                window.webview.stop_loading()
                window.destroy()
            self.main_window = None
            self.create_web_context()
            self.do_activate()
            if maximized:
                self.main_window.maximize()
        finally:
            self._recovering_player = False
            self.release()

    def add_action_callback(self, name, callback):
        action = Gio.SimpleAction.new(name, None)
        action.connect("activate", callback)
        self.add_action(action)

    def do_activate(self):
        if self.main_window is None:
            self.main_window = MusicWindow(self)
            self.main_window.connect("destroy", self.on_main_destroy)
            self.watch_login_window(self.main_window)
            self.main_window.webview.load_uri(HOME_URL)
        self.main_window.present()

    def do_shutdown(self):
        self.system_media.close()
        self.stop_login_watch()
        if self.main_window:
            self.save_state(self.main_window)
        Gtk.Application.do_shutdown(self)

    def media_control(self, action, args):
        if self.main_window is None or not is_player_uri(self.main_window.webview.get_uri()):
            return
        script = "window.__neteaseSystemMedia && window.__neteaseSystemMedia(%s, %s)" % (
            json.dumps(action), json.dumps(args))
        self.main_window.webview.run_javascript(script, None, None, None)

    def start_login_watch(self):
        self._login_windows = weakref.WeakSet()
        self._login_fingerprint = None
        self._login_read_pending = False
        self._login_read_again = False
        self._login_return_timer = 0
        self._login_document_serial = 0
        self._login_watch_active = True
        self._login_cancellable = Gio.Cancellable()
        self._login_cookie_manager = self.manager.get_cookie_manager()
        self._login_cookie_signal = self._login_cookie_manager.connect(
            "changed", self.check_login_cookies)
        self.check_login_cookies()

    def stop_login_watch(self):
        if not getattr(self, "_login_watch_active", False):
            return
        self._login_watch_active = False
        self._login_cookie_manager.disconnect(self._login_cookie_signal)
        self._login_cancellable.cancel()
        if self._login_return_timer:
            GLib.source_remove(self._login_return_timer)
            self._login_return_timer = 0
        self._login_windows.clear()

    def watch_login_window(self, window):
        window.webview.connect("notify::uri", self.login_uri_changed, window)
        window.webview.connect("load-changed", self.login_document_changed, window)
        self.login_uri_changed(window.webview, None, window)

    def login_document_changed(self, _view, event, window):
        if (self._login_watch_active and window is self.main_window
                and event == WebKit2.LoadEvent.COMMITTED):
            self._login_document_serial += 1

    def login_uri_changed(self, view, _spec, window):
        if not self._login_watch_active:
            return
        uri = view.get_uri()
        if is_login_uri(uri):
            self._login_windows.add(window)
            self.check_login_cookies()
        elif ((is_player_uri(uri) and window is self.main_window)
              or (uri and not is_music_uri(uri))):
            self._login_windows.discard(window)

    def check_login_cookies(self, *_):
        if not self._login_watch_active:
            return
        if self._login_read_pending:
            self._login_read_again = True
            return
        self._login_read_pending = True
        self._login_cookie_manager.get_cookies(
            HOME_URL, self._login_cancellable, self.login_cookies_ready, None)

    def login_cookies_ready(self, manager, result, _data):
        try:
            cookies = manager.get_cookies_finish(result) or []
        except GLib.Error:
            cookies = None
        if not self._login_watch_active or manager != self._login_cookie_manager:
            return
        self._login_read_pending = False
        if cookies is not None:
            previous = self._login_fingerprint
            self._login_fingerprint = login_cookie_fingerprint(cookies)
            if (previous is not None and self._login_fingerprint
                    and previous != self._login_fingerprint and self._login_windows):
                if self._login_return_timer:
                    GLib.source_remove(self._login_return_timer)
                self._login_return_timer = GLib.timeout_add(
                    600, self.return_after_login, self._login_fingerprint,
                    self._login_document_serial)
        if self._login_read_again:
            self._login_read_again = False
            self.check_login_cookies()

    def return_after_login(self, fingerprint, document_serial):
        self._login_return_timer = 0
        if not self._login_watch_active or fingerprint != self._login_fingerprint:
            return False
        windows = self.get_windows()
        login_windows = [window for window in self._login_windows
                         if window in windows and is_music_uri(window.webview.get_uri())]
        # Consume the transition before navigating. A rejected/stale session
        # must not cause a loop between the player and the login page.
        self._login_windows.clear()
        main = self.main_window
        if not login_windows or main is None or main not in windows:
            return False
        if not is_music_uri(main.webview.get_uri()):
            return False
        # A popup can finish while the player still shows its old account state.
        # Refresh that document once, unless the site has already replaced it.
        popup_login = any(window is not main for window in login_windows)
        if (not is_player_uri(main.webview.get_uri()) or is_login_uri(main.webview.get_uri())
                or (popup_login and document_serial == self._login_document_serial)):
            main.webview.load_uri(HOME_URL)
        for window in login_windows:
            if window is not main:
                window.destroy()
        main.present()
        return False

    def on_main_destroy(self, *_):
        self.main_window = None
        for window in list(self.get_windows()):
            window.destroy()

    def on_download(self, _context, download):
        download.connect("decide-destination", self.choose_download)
        download.connect("failed", self.download_failed)

    def choose_download(self, download, suggested_name):
        parent = self.get_active_window()
        # The player entry page is a document, never an installation download.
        # Keep an unexpected response visible instead of saving a 'webplayer' file.
        response = download.get_response()
        if response and is_player_uri(response.get_uri()):
            download.cancel()
            view = download.get_web_view()
            window = view.get_toplevel() if view else self.main_window
            if isinstance(window, MusicWindow):
                window.show_error(page_response_error(response))
            return True
        chooser = Gtk.FileChooserDialog(title="保存文件", transient_for=parent,
                                       action=Gtk.FileChooserAction.SAVE)
        chooser.add_buttons("取消", Gtk.ResponseType.CANCEL, "保存", Gtk.ResponseType.ACCEPT)
        chooser.set_do_overwrite_confirmation(True)
        chooser.set_current_name(Path(suggested_name).name or "download")
        folder = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD)
        if folder and Path(folder).is_dir():
            chooser.set_current_folder(folder)
        if chooser.run() == Gtk.ResponseType.ACCEPT:
            download.set_allow_overwrite(True)
            download.set_destination(Path(chooser.get_filename()).as_uri())
        else:
            download.cancel()
        chooser.destroy()
        return True

    def download_failed(self, _download, error):
        if error.matches(WebKit2.download_error_quark(), WebKit2.DownloadError.CANCELLED_BY_USER):
            return
        window = self.get_active_window()
        if window:
            window.message("下载失败", error.message)

    def log_playback(self, message):
        """Keep a small local record of playback decisions for troubleshooting.

        Messages contain events, positions and sizes only, never addresses or
        account data. The file is replaced once it reaches its size limit."""
        path = self.cache_dir / "playback.log"
        try:
            if path.exists() and path.stat().st_size > PLAYBACK_LOG_LIMIT:
                path.replace(path.with_name("playback.log.1"))
            with path.open("a", encoding="utf-8") as stream:
                record = dict(message, at=round(time.time(), 2))
                stream.write(json.dumps(record, ensure_ascii=False) + "\n")
        except (OSError, TypeError, ValueError):
            pass

    def load_audio_cache_directory(self):
        try:
            path = Path(json.loads(self.audio_cache_config.read_text(encoding="utf-8")))
            if path.is_absolute() and "\0" not in str(path):
                return path
        except (OSError, TypeError, ValueError):
            pass
        return self.default_audio_cache_directory

    def save_audio_cache_directory(self, path):
        if path.is_symlink():
            raise OSError("缓存子目录指向符号链接")
        path.mkdir(mode=0o700, exist_ok=True)
        with tempfile.TemporaryFile(dir=path):
            pass
        if path == self.default_audio_cache_directory:
            self.audio_cache_config.unlink(missing_ok=True)
        else:
            temp = self.audio_cache_config.with_suffix(".tmp")
            temp.write_text(json.dumps(str(path)), encoding="utf-8")
            temp.replace(self.audio_cache_config)
        self.audio_cache_directory = path

    def save_download_preferences(self, directory, format_name):
        temp = self.download_config.with_suffix(".tmp")
        temp.write_text(json.dumps({"directory": str(directory), "format": format_name}), encoding="utf-8")
        temp.replace(self.download_config)
        self.download_directory, self.download_format = directory, format_name

    def load_transition(self):
        try:
            settings = json.loads(self.transition_config.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            settings = None
        return transition_settings(settings if isinstance(settings, dict) else {})

    def save_transition(self, settings):
        settings = transition_settings(settings)
        temp = self.transition_config.with_suffix(".tmp")
        temp.write_text(json.dumps(settings), encoding="utf-8")
        temp.replace(self.transition_config)
        self.transition = settings

    def save_state(self, window):
        width, height = window.normal_size
        self.state = {"width": width, "height": height, "zoom": window.requested_zoom}
        try:
            temp = self.state_path.with_suffix(".tmp")
            temp.write_text(json.dumps(self.state), encoding="utf-8")
            temp.chmod(0o600)
            temp.replace(self.state_path)
        except OSError:
            pass


class MusicWindow(Gtk.ApplicationWindow):
    def __init__(self, app, related_view=None):
        super().__init__(application=app, title=APP_NAME)
        self.app = app
        self.is_popup = related_view is not None
        self.desktop_lyrics = None
        self.download_job = None
        self.download_state = None
        self.download_scan = None
        self.connect("destroy", self.stop_download)
        self.set_role(APP_ID)
        self.set_wmclass(APP_ID, APP_ID)
        display = self.get_display()
        monitor = display.get_primary_monitor() or display.get_monitor(0)
        workarea = monitor.get_workarea() if monitor else None
        available = ((workarea.width, workarea.height)
                     if workarea and min(workarea.width, workarea.height) > 0 else (7680, 4320))
        state = {} if self.is_popup else app.state
        minimum, self.normal_size = opening_window_geometry(state, available)
        self.set_size_request(*minimum)
        def number(key, default, low, high):
            value = state.get(key, default)
            return max(low, min(high, value)) if isinstance(value, (int, float)) else default
        self.set_default_size(*self.normal_size)

        self.set_decorated(False)
        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        self.alpha_corners = bool(visual and screen.is_composited())
        self.corner_geometry = None
        self.corner_clip = None
        if self.alpha_corners:
            self.set_visual(visual)
            self.set_app_paintable(True)
        self.connect_after("realize", self.sync_corner_region)
        self.connect_after("size-allocate", self.sync_corner_region)
        self.connect("notify::scale-factor", self.sync_corner_region)

        self.webview = create_webview(app.context, related_view)
        settings = WebKit2.Settings()
        # The site only admits Firefox >=91 / Chrome >=84 via a UA regex.
        # Use its Firefox compatibility path; the actual engine stays WebKitGTK.
        settings.set_user_agent("Mozilla/5.0 (X11; Linux x86_64; rv:128.0) "
                                "Gecko/20100101 Firefox/128.0")
        settings.set_enable_javascript(True)
        settings.set_enable_mediasource(True)
        settings.set_enable_webaudio(True)
        settings.set_media_playback_requires_user_gesture(False)
        settings.set_javascript_can_open_windows_automatically(False)
        # NetEase calls this API unconditionally during React startup. WebKitGTK
        # 2.52 includes it as a feature that is disabled by default.
        if hasattr(WebKit2.Settings, "get_all_features"):
            features = WebKit2.Settings.get_all_features()
            for index in range(features.get_length()):
                feature = features.get(index)
                if feature.get_identifier() == "RequestIdleCallback":
                    settings.set_feature_enabled(feature, True)
                    break
        self.webview.set_settings(settings)
        # Older WebKitGTK releases need the standard timer fallback instead.
        # It is scoped to the music site and never replaces a native API.
        if not related_view:
            self.webview.get_user_content_manager().add_script(WebKit2.UserScript.new(
                """if (!window.requestIdleCallback) {
                    window.requestIdleCallback = function(callback) {
                        return setTimeout(function() {
                            var start = performance.now();
                            callback({didTimeout: false, timeRemaining: function() {
                                return Math.max(0, 50 - (performance.now() - start));
                            }});
                        }, 1);
                    };
                    window.cancelIdleCallback = function(id) { clearTimeout(id); };
                }""",
                WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/*"], None))
            manager = self.webview.get_user_content_manager()
            manager.register_script_message_handler_in_world("windowDragGap", WINDOW_INTERACTION_WORLD)
            manager.connect("script-message-received::windowDragGap", self.drag_gap_message)
            interaction_script = Path(__file__).resolve().parent / "assets" / "window-interaction.js"
            manager.add_script(WebKit2.UserScript.new_for_world(
                interaction_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.END, WINDOW_INTERACTION_WORLD,
                ["https://music.163.com/st/webplayer*"], None))
            self.audio_buffer = AudioCache(WEBKIT_API, self.deliver_native_audio,
                                           app.audio_cache_directory)
            self.cache_chooser = None
            manager.register_script_message_handler_in_world("cacheSettings", CACHE_SETTINGS_WORLD)
            manager.connect("script-message-received::cacheSettings", self.cache_settings_message)
            cache_script = Path(__file__).resolve().parent / "assets" / "cache-settings.js"
            manager.add_script(WebKit2.UserScript.new_for_world(
                cache_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.END, CACHE_SETTINGS_WORLD,
                ["https://music.163.com/st/webplayer*"], None))
            if not self.is_popup:
                manager.register_script_message_handler_in_world("musicDownload", CACHE_SETTINGS_WORLD)
                manager.connect("script-message-received::musicDownload", self.music_download_message)
                script = Path(__file__).resolve().parent / "assets" / "music-downloads.js"
                manager.add_script(WebKit2.UserScript.new_for_world(
                    script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                    WebKit2.UserScriptInjectionTime.END, CACHE_SETTINGS_WORLD,
                    ["https://music.163.com/st/webplayer*"], None))
                targets = script.with_name("download-targets.js")
                manager.add_script(WebKit2.UserScript.new(
                    targets.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                    WebKit2.UserScriptInjectionTime.END, ["https://music.163.com/st/webplayer*"], None))
            manager.register_script_message_handler_in_world("transitionSettings", CACHE_SETTINGS_WORLD)
            manager.connect("script-message-received::transitionSettings", self.transition_settings_message)
            transition_script = Path(__file__).resolve().parent / "assets" / "transition-settings.js"
            manager.add_script(WebKit2.UserScript.new_for_world(
                transition_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.END, CACHE_SETTINGS_WORLD,
                ["https://music.163.com/st/webplayer*"], None))
            self.stream_player = StreamPlayer(self.audio_buffer, self.deliver_stream, transition=app.transition)
            manager.register_script_message_handler("streamPlayer")
            manager.connect("script-message-received::streamPlayer", self.stream_message)
            self.quality_service = QualityService(self.audio_buffer.client,
                app.manager.get_cookie_manager(), self.deliver_quality)
            manager.register_script_message_handler("musicQuality")
            manager.connect("script-message-received::musicQuality", self.quality_message)
            certificate = Gio.TlsCertificate.new_from_pem(self.audio_buffer.certificate, -1)
            app.context.allow_tls_certificate_for_host(certificate, "127.0.0.1")
            self.connect("destroy", lambda *_: self.stream_player.close())
            self.connect("destroy", lambda *_: self.audio_buffer.close())
            self.connect("destroy", lambda *_: self.quality_service.cancel_all())
            manager.register_script_message_handler("nativeAudio")
            manager.connect("script-message-received::nativeAudio", self.native_audio_message)
            readiness_script = Path(__file__).resolve().parent / "assets" / "media-readiness.js"
            manager.add_script(WebKit2.UserScript.new(
                readiness_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/*"], None))
            native_script = Path(__file__).resolve().parent / "assets" / "native-audio.js"
            manager.add_script(WebKit2.UserScript.new(
                native_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/st/webplayer*"], None))
            streaming_script = Path(__file__).resolve().parent / "assets" / "native-streaming.js"
            manager.add_script(WebKit2.UserScript.new(
                streaming_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/st/webplayer*"], None))
            decoded_script = Path(__file__).resolve().parent / "assets" / "web-audio-playback.js"
            manager.add_script(WebKit2.UserScript.new(
                decoded_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/*"], None))
            state_script = Path(__file__).resolve().parent / "assets" / "decoded-media-state.js"
            manager.add_script(WebKit2.UserScript.new(
                state_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/*"], None))
            quality_script = Path(__file__).resolve().parent / "assets" / "audio-quality.js"
            manager.add_script(WebKit2.UserScript.new(
                quality_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/st/webplayer*"], None))
            buffer_script = Path(__file__).resolve().parent / "assets" / "buffered-playback.js"
            manager.add_script(WebKit2.UserScript.new(
                buffer_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/st/webplayer*"], None))
            manager.register_script_message_handler("playbackRecovery")
            manager.connect("script-message-received::playbackRecovery", self.playback_recovery_message)
            script = Path(__file__).resolve().parent / "assets" / "playback-recovery.js"
            manager.add_script(WebKit2.UserScript.new(
                script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/st/webplayer*"], None))
            if not self.is_popup:
                manager.register_script_message_handler_in_world("desktopLyricsSettings", CACHE_SETTINGS_WORLD)
                manager.connect("script-message-received::desktopLyricsSettings", self.desktop_lyrics_settings_message)
                manager.register_script_message_handler("desktopLyrics")
                manager.connect("script-message-received::desktopLyrics", self.desktop_lyrics_message)
                lyric_script = Path(__file__).resolve().parent / "assets" / "desktop-lyrics.js"
                manager.add_script(WebKit2.UserScript.new(
                    lyric_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                    WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/st/webplayer*"], None))
                self.connect("destroy", self.destroy_desktop_lyrics)
                manager.register_script_message_handler("systemMedia")
                manager.connect("script-message-received::systemMedia", self.system_media_message)
                media_script = Path(__file__).resolve().parent / "assets" / "system-media.js"
                manager.add_script(WebKit2.UserScript.new(
                    media_script.read_text(encoding="utf-8"), WebKit2.UserContentInjectedFrames.TOP_FRAME,
                    WebKit2.UserScriptInjectionTime.START, ["https://music.163.com/st/webplayer*"], None))
        self.requested_zoom = number("zoom", 1.0, 0.5, 2.0)
        self.viewport_size = self.normal_size
        self.page_scale = 1.0
        self.viewport_timer = 0
        self.compact_header = None
        self.webview.set_zoom_level(fit_page_zoom(self.requested_zoom, self.viewport_size, self.page_scale))
        self.webview.connect("load-changed", self.load_changed)
        self.webview.connect("load-failed", self.load_failed)
        self.webview.connect("load-failed-with-tls-errors", self.tls_failed)
        self.webview.connect("notify::title", self.title_changed)
        self.webview.connect("decide-policy", self.decide_policy)
        self.webview.connect("create", self.create_popup)
        self.webview.connect("close", lambda *_: self.destroy())
        self.webview.connect("web-process-terminated", self.process_terminated)
        self.webview.connect("permission-request", self.permission_request)
        self.webview.connect("enter-fullscreen", self.enter_fullscreen)
        self.webview.connect("leave-fullscreen", self.leave_fullscreen)
        self.webview.connect("resource-load-started", self.playback_resource_started)

        self.overlay = Gtk.Overlay()
        self.add(self.overlay)
        self.progress = Gtk.ProgressBar()
        self.progress.set_no_show_all(True)
        self.progress.set_valign(Gtk.Align.START)
        self.webview.connect("notify::estimated-load-progress", self.progress_changed)
        self.stack = Gtk.Stack()
        self.overlay.add(self.stack)
        self.stack.add_named(self.webview, "web")
        self.overlay.add_overlay(self.progress)
        self.overlay.set_overlay_pass_through(self.progress, True)
        self.playback_notice = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10,
                                      halign=Gtk.Align.CENTER, valign=Gtk.Align.END)
        self.playback_notice.set_margin_bottom(100)
        self.playback_notice.set_no_show_all(True)
        self.playback_notice.pack_start(Gtk.Label(label="播放连接异常"), False, False, 0)
        recover = Gtk.Button(label="恢复播放器")
        recover.set_tooltip_text("重新建立播放和网络会话，保留登录；也可按 Ctrl+Shift+R")
        recover.connect("clicked", self.app.recover_player)
        self.playback_notice.pack_start(recover, False, False, 0)
        dismiss = Gtk.Button(label="关闭提示")
        dismiss.connect("clicked", lambda *_: self.playback_notice.hide())
        self.playback_notice.pack_start(dismiss, False, False, 0)
        self.overlay.add_overlay(self.playback_notice)
        error_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16,
                            halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER, margin=32)
        error_box.pack_start(Gtk.Image.new_from_icon_name("network-error-symbolic", Gtk.IconSize.DIALOG), False, False, 0)
        self.error_label = Gtk.Label(label="页面暂时无法打开", wrap=True, justify=Gtk.Justification.CENTER)
        self.error_label.set_max_width_chars(60)
        error_box.pack_start(self.error_label, False, False, 0)
        retry = Gtk.Button(label="重新加载")
        retry.connect("clicked", self.app.recover_player)
        error_box.pack_start(retry, False, False, 0)
        self.stack.add_named(error_box, "error")
        self.create_window_controls()
        self.create_window_interaction()
        self.header_style = None
        self.webview.connect("notify::zoom-level", self.sync_page_controls)
        self.webview.connect("notify::scale-factor", self.sync_page_controls)
        self.webview.connect("size-allocate", self.viewport_size_changed)
        self.connect("destroy", self.cancel_viewport_fit)
        self.sync_page_controls()
        self.connect("key-press-event", self.key_press)
        self.connect("configure-event", self.configure)
        self.connect("delete-event", self.before_close)
        self.connect("window-state-event", self.window_state_changed)
        self.show_all()
        self.set_focus(self.webview)
        self.update_window_interaction()

    def do_draw(self, cr):
        if not self.alpha_corners:
            return Gtk.ApplicationWindow.do_draw(self, cr)
        width, height = self.get_allocated_width(), self.get_allocated_height()
        cr.save()
        if self.corner_clip is not None:
            radius = min(WINDOW_CORNER_RADIUS, width // 2, height // 2)
            operator = cr.get_operator()
            cr.set_operator(cairo.OPERATOR_CLEAR)
            for x in (0, width - radius):
                for y in (0, height - radius):
                    cr.rectangle(x, y, radius, radius)
            cr.fill()
            cr.set_operator(operator)
            # A region of pixel-aligned rectangles also clips WebKit's direct GL drawing.
            Gdk.cairo_region(cr, self.corner_clip)
            cr.clip()
        Gtk.render_background(self.get_style_context(), cr, 0, 0, width, height)
        handled = Gtk.ApplicationWindow.do_draw(self, cr)
        cr.restore()
        return handled

    def sync_corner_region(self, *_, state=None):
        window = self.get_window()
        if not window:
            return
        width, height = self.get_allocated_width(), self.get_allocated_height()
        if state is None:
            state = window.get_state()
        square_corners = bool(state & (Gdk.WindowState.MAXIMIZED | Gdk.WindowState.FULLSCREEN))
        geometry = (window, width, height, window.get_scale_factor(), square_corners)
        if geometry == self.corner_geometry:
            return
        self.corner_geometry = geometry
        region = None
        if not square_corners:
            from desktop_lyrics import rounded_rectangles
            region = cairo.Region([cairo.RectangleInt(*rect) for rect in
                                   rounded_rectangles(width, height, WINDOW_CORNER_RADIUS)])
        self.corner_clip = region
        display = window.get_display()
        # A native X11 bounding mask can clip newly allocated content during resize.
        if not self.alpha_corners and display.supports_shapes():
            window.shape_combine_region(region, 0, 0)
        elif display.supports_input_shapes():
            self.input_shape_combine_region(region)
        self.queue_draw()

    def create_window_controls(self):
        # Native controls float over the page; there is no title bar or toolbar,
        # and webpage scripts do not receive a bridge into window operations.
        self.window_controls = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                                       spacing=WINDOW_BUTTON_SPACING)
        self.window_controls.set_halign(Gtk.Align.END)
        self.window_controls.set_valign(Gtk.Align.START)
        self.window_controls.set_margin_end(WINDOW_BUTTON_END)
        self.window_controls.set_margin_top(22)
        css = Gtk.CssProvider()
        css.load_from_data(b"""
            button.music-window-control {
                min-width: %dpx; min-height: %dpx; padding: 0; margin: 0;
                border: 0; border-radius: 5px; box-shadow: none;
                background-image: none; background-color: transparent;
                color: #7b8090; outline: 1px solid currentColor; outline-offset: 2px;
            }
            button.music-window-control:hover { background-color: rgba(123,128,144,0.08); }
            button.music-window-control:active { background-color: rgba(123,128,144,0.14); }
            button.music-window-close:hover { background-color: rgba(255,56,87,0.07); color: #ff3857; }
        """ % (WINDOW_BUTTON_SIZE, WINDOW_BUTTON_SIZE))
        self.control_buttons = {}
        for name, icon, tip, callback in [
            ("minimize", "netease-window-minimize-symbolic", "最小化", lambda *_: self.iconify()),
            ("maximize", "netease-window-maximize-symbolic", "最大化", self.toggle_maximize),
            ("close", "netease-window-close-symbolic", "关闭", lambda *_: self.close()),
        ]:
            button = Gtk.Button(focus_on_click=False)
            image = Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.MENU)
            image.set_pixel_size(22)
            button.set_image(image)
            button.set_tooltip_text(tip)
            button.get_accessible().set_name(tip)
            context = button.get_style_context()
            context.add_class("music-window-control")
            if name == "close":
                context.add_class("music-window-close")
            context.add_provider(css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            button.connect("button-press-event", self.window_control_pressed)
            button.connect("clicked", callback)
            self.window_controls.pack_start(button, False, False, 0)
            self.control_buttons[name] = button
        self.overlay.add_overlay(self.window_controls)

    def window_control_pressed(self, _button, event):
        if event.button == 1 and self.get_focus() in self.control_buttons.values():
            self.set_focus(None)
            self.stack.child_focus(Gtk.DirectionType.TAB_FORWARD)
        return False

    def create_window_interaction(self):
        # A borderless window still needs native movement and resize grips.
        # Native grips receive pointer events synchronously on X11 and Wayland.
        self.resize_handles = []
        edges = [
            (Gdk.WindowEdge.NORTH, "n-resize", Gtk.Align.FILL, Gtk.Align.START, 6, 0),
            (Gdk.WindowEdge.SOUTH, "s-resize", Gtk.Align.FILL, Gtk.Align.END, 6, 0),
            (Gdk.WindowEdge.WEST, "w-resize", Gtk.Align.START, Gtk.Align.FILL, 0, 6),
            (Gdk.WindowEdge.EAST, "e-resize", Gtk.Align.END, Gtk.Align.FILL, 0, 6),
            (Gdk.WindowEdge.NORTH_WEST, "nw-resize", Gtk.Align.START, Gtk.Align.START, 12, 12),
            (Gdk.WindowEdge.NORTH_EAST, "ne-resize", Gtk.Align.END, Gtk.Align.START, 12, 12),
            (Gdk.WindowEdge.SOUTH_WEST, "sw-resize", Gtk.Align.START, Gtk.Align.END, 12, 12),
            (Gdk.WindowEdge.SOUTH_EAST, "se-resize", Gtk.Align.END, Gtk.Align.END, 12, 12),
        ]
        for edge, cursor, horizontal, vertical, height, width in edges:
            handle = self.create_input_grip(cursor)
            handle.set_halign(horizontal)
            handle.set_valign(vertical)
            handle.set_size_request(width, height)
            if horizontal == Gtk.Align.FILL:
                handle.set_margin_start(12)
                handle.set_margin_end(12)
            if vertical == Gtk.Align.FILL:
                handle.set_margin_top(12)
                handle.set_margin_bottom(12)
            handle.connect("button-press-event", self.resize_pressed, edge)
            self.overlay.add_overlay(handle)
            self.resize_handles.append(handle)

        self.drag_handle = self.create_input_grip("grab")
        self.drag_handle.set_halign(Gtk.Align.FILL)
        self.drag_handle.set_valign(Gtk.Align.START)
        self.drag_handle.set_margin_start(12)
        self.drag_handle.set_margin_end(144)
        self.drag_handle.set_margin_top(6)
        self.drag_handle.set_size_request(0, 12)
        self.drag_handle.set_tooltip_text("拖动窗口；双击最大化或还原")
        self.drag_handle.connect("button-press-event", self.move_pressed)
        self.overlay.add_overlay(self.drag_handle)

        self.drag_gap_bounds = None
        self.drag_gap = self.create_input_grip("grab")
        self.drag_gap.set_halign(Gtk.Align.START)
        self.drag_gap.set_valign(Gtk.Align.START)
        self.drag_gap.connect("button-press-event", self.move_pressed)
        self.overlay.add_overlay(self.drag_gap)

    def clear_drag_gap(self):
        self.drag_gap_bounds = None
        self.drag_gap.hide()

    def drag_gap_message(self, _manager, result):
        window = self.get_window()
        if not window or not is_player_uri(self.webview.get_uri()) or self.stack.get_visible_child_name() != "web":
            return
        try:
            viewport = json.loads(result.get_js_value().to_string())
            if viewport is None:
                self.clear_drag_gap()
                return
            width, height, ratio, left, top, right, bottom = viewport
            scale = ratio / self.webview.get_scale_factor()
            if not 0 < scale <= 8 or not (0 <= left < right <= width and 0 <= top < bottom <= height):
                return
            if any(abs(css * scale - native) > 3
                   for css, native in zip((width, height), self.viewport_size)):
                return
            x = max(12, math.ceil(left * scale))
            y = max(6, math.ceil(top * scale))
            right = min(self.viewport_size[0] - 12, math.floor(right * scale))
            bottom = math.floor(bottom * scale)
        except (ValueError, TypeError, OverflowError):
            return
        bounds = (x, y, right - x, bottom - y)
        if min(bounds[2:]) < 12:
            self.clear_drag_gap()
            return
        self.drag_gap_bounds = bounds
        self.drag_gap.set_margin_start(x)
        self.drag_gap.set_margin_top(y)
        self.drag_gap.set_size_request(*bounds[2:])
        self.drag_gap.set_visible(not window.get_state() & Gdk.WindowState.FULLSCREEN)

    def create_input_grip(self, cursor_name):
        grip = Gtk.EventBox()
        grip.set_visible_window(False)
        grip.set_above_child(True)
        grip.set_no_show_all(True)
        grip.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.ENTER_NOTIFY_MASK)
        # The event belongs to the input-only grip window, not to the WebView.
        def enter(widget, event):
            event.window.set_cursor(Gdk.Cursor.new_from_name(widget.get_display(), cursor_name))
            return False
        grip.connect("enter-notify-event", enter)
        return grip

    def update_window_interaction(self, state=None):
        if state is None:
            window = self.get_window()
            state = window.get_state() if window else 0
        fullscreen = bool(state & Gdk.WindowState.FULLSCREEN)
        resizable = self.get_resizable() and not state & (
            Gdk.WindowState.MAXIMIZED | Gdk.WindowState.FULLSCREEN)
        for handle in self.resize_handles:
            handle.set_visible(bool(resizable))
        self.drag_handle.set_visible(not fullscreen)
        self.drag_gap.set_visible(bool(self.drag_gap_bounds) and not fullscreen)

    def move_pressed(self, _grip, event):
        if event.button != 1:
            return False
        if event.type == Gdk.EventType.DOUBLE_BUTTON_PRESS:
            self.toggle_maximize()
            return True
        if event.type != Gdk.EventType.BUTTON_PRESS:
            return False
        self.begin_move_drag(event.button, int(event.x_root), int(event.y_root), event.time)
        return True

    def resize_pressed(self, _grip, event, edge):
        window = self.get_window()
        if (event.button != 1 or event.type != Gdk.EventType.BUTTON_PRESS
                or not self.get_resizable() or not window
                or window.get_state() & (Gdk.WindowState.MAXIMIZED | Gdk.WindowState.FULLSCREEN)):
            return False
        self.begin_resize_drag(edge, event.button, int(event.x_root), int(event.y_root), event.time)
        return True

    def sync_page_controls(self, *_):
        # The native buttons keep their size while WebKit zooms the page.
        manager = self.webview.get_user_content_manager()
        if self.header_style:
            if hasattr(manager, "remove_style_sheet"):
                manager.remove_style_sheet(self.header_style)
            else:
                # WebKitGTK 2.28 only exposes the bulk operation. This manager's
                # styles are owned by the application; user scripts are retained.
                manager.remove_all_style_sheets()
        zoom = self.webview.get_zoom_level()
        metrics = (f":root {{ --music-window-controls-width: {WINDOW_BUTTON_RESERVE / zoom:.2f}px;"
                   f" --music-window-button-pitch: {WINDOW_BUTTON_PITCH / zoom:.2f}px;"
                   f" --music-window-compact-inset: {COMPACT_HEADER_INSET / zoom:.2f}px; }}\n")
        self.header_style = WebKit2.UserStyleSheet.new(
            metrics + PLAYER_LAYOUT,
            WebKit2.UserContentInjectedFrames.TOP_FRAME, WebKit2.UserStyleLevel.USER,
            ["https://music.163.com/st/webplayer*"], None)
        manager.add_style_sheet(self.header_style)
        self.position_window_controls()

    def position_window_controls(self):
        zoom = self.webview.get_zoom_level()
        script = f"""(() => {{
            const scale = devicePixelRatio / {self.webview.get_scale_factor()};
            const style = document.documentElement.style;
            style.setProperty('--music-window-controls-width', ({WINDOW_BUTTON_RESERVE} / scale) + 'px');
            style.setProperty('--music-window-button-pitch', ({WINDOW_BUTTON_PITCH} / scale) + 'px');
            style.setProperty('--music-window-compact-inset', ({COMPACT_HEADER_INSET} / scale) + 'px');
            const compact = matchMedia('(max-width: {COMPACT_WIDTH}px)').matches;
            const result = center => JSON.stringify([center, scale, compact]);
            if (compact) return result({COMPACT_BUTTON_CENTER});
            const nav = document.getElementById('page_pc_main_nav');
            if (!nav) return result(36 * scale);
            const icons = nav.querySelectorAll('[class*="MiniModeIconBar_"] .icon');
            for (const icon of icons) {{
                const rect = icon.getBoundingClientRect();
                if (rect.width && rect.height) return result((rect.top + rect.height / 2) * scale);
            }}
            const rect = nav.getBoundingClientRect();
            return result((rect.top + rect.height / 2) * scale);
        }})()"""
        # Ubuntu 22.04 can provide WebKitGTK 2.36, before the 2.40 API.
        # Both paths run the same layout query and keep the native controls.
        if hasattr(self.webview, "evaluate_javascript"):
            self.webview.evaluate_javascript(
                script, -1, None, None, None, self.control_position_ready, (False, zoom))
        else:
            self.webview.run_javascript(script, None, self.control_position_ready, (True, zoom))

    def control_position_ready(self, view, task, request):
        legacy_api, zoom = request
        try:
            if legacy_api:
                value = view.run_javascript_finish(task).get_js_value()
            else:
                value = view.evaluate_javascript_finish(task)
            center, scale, compact = json.loads(value.to_string())
            if self.get_window() and zoom == view.get_zoom_level() and 0 < scale <= 8:
                self.compact_header = compact
                if abs(scale / zoom - self.page_scale) > 0.01:
                    self.page_scale = scale / zoom
                    self.queue_viewport_fit()
                margin = round(center - WINDOW_BUTTON_SIZE / 2)
                self.window_controls.set_margin_top(max(6, min(120, margin)))
        except (GLib.Error, TypeError, ValueError):
            pass

    def viewport_size_changed(self, _view, allocation):
        size = (allocation.width, allocation.height)
        if min(size) > 1 and size != self.viewport_size:
            self.viewport_size = size
            self.clear_drag_gap()
            self.queue_viewport_fit()

    def queue_viewport_fit(self):
        if not self.viewport_timer:
            self.viewport_timer = GLib.timeout_add(100, self.update_viewport_fit)

    def cancel_viewport_fit(self, *_):
        if self.viewport_timer:
            GLib.source_remove(self.viewport_timer)
            self.viewport_timer = 0

    def update_viewport_fit(self):
        self.viewport_timer = 0
        zoom = fit_page_zoom(self.requested_zoom, self.viewport_size, self.page_scale)
        if zoom != self.webview.get_zoom_level():
            self.webview.set_zoom_level(zoom)
        else:
            compact = self.viewport_size[0] <= COMPACT_WIDTH * zoom * self.page_scale
            if compact != self.compact_header:
                self.position_window_controls()
        return False

    def toggle_maximize(self, *_):
        if self.is_maximized():
            self.unmaximize()
        else:
            self.maximize()

    def window_state_changed(self, _window, event):
        if event.changed_mask & (Gdk.WindowState.MAXIMIZED | Gdk.WindowState.FULLSCREEN):
            self.sync_corner_region(state=event.new_window_state)
        # Focus/minimize events must not rebuild the image: Gtk.Image clears its
        # old content and queues a resize even when the icon name is unchanged.
        if event.changed_mask & Gdk.WindowState.MAXIMIZED:
            maximized = bool(event.new_window_state & Gdk.WindowState.MAXIMIZED)
            button = self.control_buttons["maximize"]
            button.get_image().set_from_icon_name(
                "netease-window-restore-symbolic" if maximized else "netease-window-maximize-symbolic", Gtk.IconSize.MENU)
            label = "还原" if maximized else "最大化"
            button.set_tooltip_text(label)
            button.get_accessible().set_name(label)
        if event.changed_mask & Gdk.WindowState.FULLSCREEN:
            self.window_controls.set_visible(not event.new_window_state & Gdk.WindowState.FULLSCREEN)
        if event.changed_mask & (Gdk.WindowState.MAXIMIZED | Gdk.WindowState.FULLSCREEN):
            self.update_window_interaction(event.new_window_state)
        return False

    def configure(self, _window, event):
        if not self.is_maximized() and not self.get_window().get_state() & Gdk.WindowState.FULLSCREEN:
            self.normal_size = (event.width, event.height)
        return False

    def before_close(self, *_):
        if not self.is_popup:
            self.app.save_state(self)
        return False

    def zoom(self, delta):
        self.requested_zoom = max(0.5, min(2.0, self.requested_zoom + delta))
        self.queue_viewport_fit()

    def key_press(self, _window, event):
        key = Gdk.keyval_name(event.keyval)
        ctrl = event.state & Gdk.ModifierType.CONTROL_MASK
        alt = event.state & Gdk.ModifierType.MOD1_MASK
        shift = event.state & Gdk.ModifierType.SHIFT_MASK
        if ctrl and shift and key.lower() == "r":
            self.app.recover_player()
        elif ctrl and not (shift or alt or self.is_popup) and key.lower() == "d":
            self.show_desktop_lyrics(not self.desktop_lyrics_visible())
        elif key == "F5" or (ctrl and key.lower() == "r"):
            self.webview.reload()
        elif alt and key == "Home":
            self.webview.load_uri(HOME_URL)
        elif ctrl and key in ("plus", "equal", "KP_Add"):
            self.zoom(0.1)
        elif ctrl and key in ("minus", "KP_Subtract"):
            self.zoom(-0.1)
        elif ctrl and key in ("0", "KP_0"):
            self.requested_zoom = 1.0
            self.queue_viewport_fit()
        elif alt and key == "Left":
            self.webview.go_back()
        elif alt and key == "Right":
            self.webview.go_forward()
        elif key == "Escape":
            self.leave_fullscreen(self.webview)
            return False
        else:
            return False
        return True

    def load_changed(self, view, event):
        if event == WebKit2.LoadEvent.STARTED:
            self.clear_drag_gap()
            if hasattr(self, "stream_player"):
                self.stream_player.close()
            if hasattr(self, "quality_service"):
                self.quality_service.cancel_all()
            if hasattr(self, "audio_buffer"):
                self.audio_buffer.cancel_all()
            if not self.is_popup:
                self.get_application().system_media.reset()
                self.sync_lyrics_playback()
            if self.desktop_lyrics:
                self.desktop_lyrics.set_track("", "", "")
            self.playback_notice.hide()
            self.stack.set_visible_child_name("web")
            self.progress.show()
        elif event == WebKit2.LoadEvent.FINISHED:
            self.progress.hide()
            self.position_window_controls()
            if self.desktop_lyrics_visible():
                self.sync_desktop_lyrics()

    def progress_changed(self, view, _spec):
        self.progress.set_fraction(view.get_estimated_load_progress())

    def title_changed(self, view, _spec):
        title = view.get_title() or APP_NAME
        self.set_title(title)

    def show_error(self, message):
        self.clear_drag_gap()
        self.progress.hide()
        self.error_label.set_text(message)
        self.stack.set_visible_child_name("error")

    def load_failed(self, _view, _event, _uri, error):
        if error.matches(WebKit2.network_error_quark(), WebKit2.NetworkError.CANCELLED):
            return False
        if error.matches(WebKit2.policy_error_quark(), WebKit2.PolicyError.FRAME_LOAD_INTERRUPTED_BY_POLICY_CHANGE):
            return False
        self.show_error("页面暂时无法打开，请检查网络后重试。\n" + error.message)
        return True

    def tls_failed(self, *_):
        self.show_error("无法验证网站的安全证书。请检查系统时间和网络后重试。")
        return True

    def process_terminated(self, *_):
        if not self.is_popup:
            self.get_application().system_media.reset()
            self.sync_lyrics_playback()
        if self.desktop_lyrics:
            self.desktop_lyrics.set_track("", "", "")
        self.show_error("网页进程已停止。点击“重新加载”继续。")

    def system_media_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        try:
            value = result.get_js_value().to_string()
            if len(value) > 16384:
                return
            message = json.loads(value)
        except (ValueError, TypeError):
            return
        self.get_application().system_media.update(message)
        self.sync_lyrics_playback()

    def native_audio_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        try:
            value = result.get_js_value().to_string()
            if len(value) > 12288:
                return
            message = json.loads(value)
        except (ValueError, TypeError):
            return
        if not isinstance(message, dict):
            return
        identifier = message.get("id")
        if not isinstance(identifier, str):
            return
        if message.get("event") == "request":
            self.audio_buffer.request(identifier, message.get("url"), background=message.get("background") is True)
        elif message.get("event") == "cancel":
            self.audio_buffer.cancel(identifier)

    def cache_settings_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        value = result.get_js_value()
        if not value.is_string():
            return
        action = value.to_string()
        if action == "read":
            self.show_cache_directory()
        elif action == "choose" and self.cache_chooser is None:
            self.choose_cache_directory()
        elif action == "reset" and self.cache_chooser is None:
            self.change_cache_directory(self.app.default_audio_cache_directory)
        elif action == "download-read":
            self.show_download_preferences()
        elif action == "download-choose" and self.cache_chooser is None:
            self.choose_download_directory()
        elif action == "download-reset":
            self.change_download_preferences(self.app.default_download_directory, self.app.download_format)
        elif action.startswith("download-format:"):
            format_name = action.split(":", 1)[1]
            if format_name in FORMATS:
                self.change_download_preferences(self.app.download_directory, format_name)

    def choose_cache_directory(self):
        chooser = Gtk.FileChooserDialog(title="选择音乐缓存存放位置", transient_for=self,
                                        modal=True, destroy_with_parent=True,
                                        action=Gtk.FileChooserAction.SELECT_FOLDER)
        self.cache_chooser = chooser
        chooser.add_buttons("取消", Gtk.ResponseType.CANCEL, "选择", Gtk.ResponseType.ACCEPT)
        directory = self.app.audio_cache_directory
        if directory.parent.is_dir():
            chooser.set_current_folder(str(directory.parent))
        try:
            folder = chooser.get_filename() if chooser.run() == Gtk.ResponseType.ACCEPT else None
        finally:
            chooser.destroy()
            self.cache_chooser = None
        if folder:
            directory = Path(folder)
            if directory not in (self.app.audio_cache_directory, self.app.default_audio_cache_directory):
                directory = directory / "netease-cloud-music-audio"
            self.change_cache_directory(directory)

    def change_cache_directory(self, directory):
        try:
            self.app.save_audio_cache_directory(directory)
        except OSError:
            self.show_cache_directory("无法写入所选目录或保存设置，请检查权限后重试。")
            return
        with self.audio_buffer.lock:
            self.audio_buffer.directory = directory
        self.show_cache_directory()

    def show_cache_directory(self, error=""):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        path = self.app.audio_cache_directory
        args = json.dumps([str(path), path != self.app.default_audio_cache_directory, error])
        script = "window.updateMusicCacheDirectory?.(..." + args + ")"
        self.webview.run_javascript_in_world(script, CACHE_SETTINGS_WORLD, None, None, None)

    def choose_download_directory(self):
        chooser = Gtk.FileChooserDialog(title="选择音乐下载目录", transient_for=self,
                                        modal=True, destroy_with_parent=True,
                                        action=Gtk.FileChooserAction.SELECT_FOLDER)
        self.cache_chooser = chooser
        chooser.add_buttons("取消", Gtk.ResponseType.CANCEL, "选择", Gtk.ResponseType.ACCEPT)
        current = self.app.download_directory
        if current.is_dir():
            chooser.set_current_folder(str(current))
        elif current.parent.is_dir():
            chooser.set_current_folder(str(current.parent))
        try:
            folder = chooser.get_filename() if chooser.run() == Gtk.ResponseType.ACCEPT else None
        finally:
            chooser.destroy()
            self.cache_chooser = None
        if folder:
            self.change_download_preferences(Path(folder), self.app.download_format)

    def change_download_preferences(self, directory, format_name):
        try:
            self.app.save_download_preferences(directory, format_name)
        except OSError:
            self.show_download_preferences("无法保存下载设置")
        else:
            self.show_download_preferences()
            self.refresh_downloaded_songs(clear=True)

    def show_download_preferences(self, error=""):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        args = json.dumps([str(self.app.download_directory), self.app.download_format,
                           self.app.download_directory != self.app.default_download_directory, error])
        self.webview.run_javascript_in_world("window.updateMusicDownloadPreferences?.(..." + args + ")",
                                            CACHE_SETTINGS_WORLD, None, None, None)

    def deliver_download(self, callback, *args):
        if self.get_window() and is_player_uri(self.webview.get_uri()):
            script = f"window.{callback}?.(...{json.dumps(args)})"
            self.webview.run_javascript_in_world(script, CACHE_SETTINGS_WORLD, None, None, None)

    def refresh_downloaded_songs(self, clear=False):
        if self.download_scan is not None and not clear:
            return
        directory, format_name = self.app.download_directory, self.app.download_format
        scan = set()
        self.download_scan = scan
        if clear:
            self.deliver_download("updateMusicDownloadedSongs", [])

        def publish(found):
            if self.download_scan is scan:
                self.download_scan = None
                self.deliver_download("updateMusicDownloadedSongs", sorted(found | scan))
            return False

        def read():
            GLib.idle_add(publish, downloaded_songs(directory, format_name))

        threading.Thread(target=read, daemon=True).start()

    def stop_download(self, *_):
        if self.download_job:
            self.download_job["stop"].set()
            self.download_job["cookies"].cancel()

    def music_download_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        value = result.get_js_value().to_string()
        if value == "read":
            self.deliver_download("updateMusicDownloadJob", self.download_state, False)
            self.refresh_downloaded_songs()
            return
        if value == "cancel":
            if self.download_job:
                self.stop_download()
                self.download_state = dict(self.download_state, message="正在取消…", cancelling=True)
                self.deliver_download("updateMusicDownloadJob", self.download_state, False)
            return
        if len(value) > 32:
            return
        kind, _, raw_id = value.partition(":")
        identifier = resource_id(raw_id)
        if kind not in ("track", "playlist") or not identifier:
            return
        if self.download_job:
            self.deliver_download("updateMusicDownloadJob", self.download_state, True)
            return
        format_name, directory = self.app.download_format, self.app.download_directory
        job = {"stop": threading.Event(), "cookies": Gio.Cancellable()}
        self.download_job = job

        def report(message, fraction, running, show=False):
            self.download_state = {"message": message, "fraction": fraction, "running": running}
            self.deliver_download("updateMusicDownloadJob", self.download_state, show)

        report(f"正在获取「{FORMATS[format_name].label}」下载授权…", 0, True, show=True)

        def progress(done, total, message):
            if self.download_job is job and not job["stop"].is_set():
                report(message, done / total, True)
            return False

        def saved(song):
            if self.download_job is job and (directory, format_name) == (
                    self.app.download_directory, self.app.download_format):
                if self.download_scan is not None:
                    self.download_scan.add(song)
                self.deliver_download("markMusicSongDownloaded", song)
            return False

        def finished(message):
            if self.download_job is job:
                self.download_job = None
                report(message, self.download_state["fraction"], False)
                self.refresh_downloaded_songs()
            return False

        def run(cookies):
            task = MusicDownloads(cookies, job["stop"])
            status = task.run(kind, identifier, directory, format_name,
                              lambda *args: GLib.idle_add(progress, *args),
                              lambda song: GLib.idle_add(saved, song))
            GLib.idle_add(finished, status)

        def authorized(manager, response):
            if self.download_job is not job:
                return
            if job["stop"].is_set():
                finished("下载已取消")
                return
            try:
                cookies = {entry.get_name(): entry.get_value()
                           for entry in manager.get_cookies_finish(response) or []}
            except GLib.Error:
                finished("无法读取登录状态")
                return
            if not cookies.get("MUSIC_U"):
                finished("请先登录网易云音乐")
                return
            threading.Thread(target=run, args=(cookies,), daemon=True).start()

        manager = self.app.manager.get_cookie_manager()
        manager.get_cookies(HOME_URL, job["cookies"], authorized)

    def transition_settings_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        text = result.get_js_value().to_string()
        try:
            message = json.loads(text) if len(text) <= 256 else None
        except ValueError:
            return
        error = ""
        if isinstance(message, dict):
            try:
                self.app.save_transition(message)
            except OSError:
                error = "无法保存过渡设置。"
            else:
                self.stream_player.configure(self.app.transition)
        elif message != "read":
            return
        args = json.dumps([self.app.transition, error])
        script = "window.updateMusicTransition?.(..." + args + ")"
        self.webview.run_javascript_in_world(script, CACHE_SETTINGS_WORLD, None, None, None)

    def quality_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        try:
            value = result.get_js_value().to_string()
            message = json.loads(value) if len(value) <= 4096 else None
        except (ValueError, TypeError):
            return
        if not isinstance(message, dict):
            return
        if message.get("event") == "cancel":
            identifier = message.get("id")
            if isinstance(identifier, str):
                self.quality_service.cancel(identifier)
        elif message.get("event") == "request":
            self.quality_service.request(message.get("id"), message.get("params"))

    def stream_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        try:
            text = result.get_js_value().to_string()
            message = json.loads(text) if len(text) <= 12288 else None
        except (ValueError, TypeError):
            return
        if isinstance(message, dict):
            self.stream_player.command(message)

    def deliver_stream(self, identifier, event, state):
        if self.get_window() and is_player_uri(self.webview.get_uri()):
            if self.desktop_lyrics_visible() and self.desktop_lyrics.stream == identifier:
                lyrics = self.desktop_lyrics
                position = state.get("position", lyrics.position / 1000)
                advancing = state.get("playing", False) and not state.get("buffering", False)
                rate = self.stream_player.track["rate"] if self.stream_player.track else 1.0
                lyrics.clock(position, advancing, rate)
            script = "window.__musicStreamEvent && window.__musicStreamEvent(%s,%s,%s)" % (
                json.dumps(identifier), json.dumps(event), json.dumps(state))
            self.webview.run_javascript(script, None, None, None)

    def desktop_lyrics_visible(self):
        return bool(self.desktop_lyrics and self.desktop_lyrics.get_visible())

    def show_desktop_lyrics(self, visible):
        if visible:
            if self.desktop_lyrics is None:
                from desktop_lyrics import DesktopLyrics
                self.desktop_lyrics = DesktopLyrics(
                    self.get_display(), lambda: self.show_desktop_lyrics(False),
                    self.app.config_dir / "desktop-lyrics.json",
                    lambda action: self.app.media_control(action, {}),
                )
            self.desktop_lyrics.show()
            self.sync_lyrics_playback()
        elif self.desktop_lyrics:
            self.desktop_lyrics.hide()
        self.sync_desktop_lyrics()

    def destroy_desktop_lyrics(self, *_):
        if self.desktop_lyrics:
            self.desktop_lyrics.destroy()
            self.desktop_lyrics = None

    def sync_lyrics_playback(self):
        if not self.desktop_lyrics_visible():
            return
        state = self.app.system_media.properties
        playing = state["PlaybackStatus"].unpack() == "Playing"
        self.desktop_lyrics.set_playback(
            playing, state["CanPause" if playing else "CanPlay"].unpack(),
            state["CanGoPrevious"].unpack(), state["CanGoNext"].unpack(),
        )

    def sync_desktop_lyrics(self):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        enabled = json.dumps(self.desktop_lyrics_visible())
        self.webview.run_javascript("window.__musicDesktopLyrics?.setVisible(" + enabled + ")", None, None, None)
        self.webview.run_javascript_in_world("window.updateDesktopLyricsSetting?.(" + enabled + ")",
                                            CACHE_SETTINGS_WORLD, None, None, None)

    def desktop_lyrics_settings_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        value = result.get_js_value().to_string()
        if value == "read":
            self.sync_desktop_lyrics()
        elif value == "toggle":
            self.show_desktop_lyrics(not self.desktop_lyrics_visible())
        elif value in ("show", "hide"):
            self.show_desktop_lyrics(value == "show")

    def desktop_lyrics_message(self, _manager, result):
        if not self.desktop_lyrics_visible() or not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        try:
            value = result.get_js_value().to_string()
            message = json.loads(value) if len(value) <= 820000 else None
        except (ValueError, TypeError):
            return
        if not isinstance(message, dict):
            return
        song = message.get("id")
        if not isinstance(song, str) or len(song) > 13 or song and not (song.isascii() and song.isdecimal()):
            return

        def text(key, limit):
            value = message.get(key)
            if not isinstance(value, str):
                return ""
            return value[:limit].replace("\0", "").encode("utf-8", "replace").decode("utf-8")

        lyrics = self.desktop_lyrics
        event = message.get("event")
        if event == "track":
            lyrics.set_track(song, text("title", 220), text("stream", 40))
            lyrics.clock(message.get("position"))
        elif song and song == lyrics.song:
            if event == "lyrics":
                lyrics.set_lyrics(song, *(text(key, 180000) for key in
                                  ("lrc", "yrc", "translation", "wordTranslation")), message.get("failed") is True)
            elif event == "position" and not lyrics.stream:
                lyrics.clock(message.get("position"), message.get("advancing") is True)

    def deliver_quality(self, identifier, data):
        if self.get_window() and is_player_uri(self.webview.get_uri()):
            self.audio_buffer.authorize_sources(data)
            source = 'window.__musicQualityResponse && window.__musicQualityResponse(%s,%s)' % (
                json.dumps(identifier), json.dumps(data))
            self.webview.run_javascript(source, None, None, None)

    def deliver_native_audio(self, identifier, event, data, continuation=None):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            self.audio_buffer.cancel(identifier)
            return
        def delivered(view, result, _):
            try:
                view.run_javascript_finish(result)
            except GLib.Error:
                self.audio_buffer.cancel(identifier)
                return
            if continuation:
                continuation()
        self.webview.run_javascript(delivery_script(identifier, event, data), None, delivered, None)

    def playback_recovery_message(self, _manager, result):
        if not self.get_window() or not is_player_uri(self.webview.get_uri()):
            return
        try:
            value = result.get_js_value().to_string()
            if len(value) > 256:
                return
            message = json.loads(value)
        except (ValueError, TypeError):
            return
        if not isinstance(message, dict):
            return
        self.app.log_playback(message)
        if message.get("event") == "failed":
            self.playback_notice.show_all()
            self.playback_notice.show()
        elif message.get("event") == "playing":
            self.playback_notice.hide()

    def playback_resource_started(self, _view, resource, request):
        try:
            parsed = urlsplit(request.get_uri())
            host = parsed.hostname or ""
        except ValueError:
            return
        audio = host.endswith(".music.126.net") and parsed.path.lower().endswith(
            (".mp3", ".flac", ".m4a", ".aac", ".ogg", ".wav"))
        player_api = host == "music.163.com" and parsed.path.startswith(
            ("/weapi/song/enhance/player/url", "/api/song/enhance/player/url"))
        if audio or player_api:
            resource.connect("failed", self.playback_resource_failed)
        elif host.endswith(".music.126.net") and parsed.path.lower().endswith(".js"):
            resource.connect("failed", self.page_component_failed)

    def page_component_failed(self, _resource, error):
        if (self.get_window() and is_player_uri(self.webview.get_uri())
                and self.webview.is_loading()
                and not error.matches(WebKit2.network_error_quark(), WebKit2.NetworkError.CANCELLED)):
            self.show_error("播放器页面的组件加载失败，请点击“重新加载”恢复网页和网络会话。")

    def playback_resource_failed(self, _resource, error):
        # Seeking and changing tracks normally cancel earlier media requests.
        if (self.get_window() and is_player_uri(self.webview.get_uri())
                and error.matches(WebKit2.network_error_quark(), WebKit2.NetworkError.FAILED)):
            self.playback_notice.show_all()
            self.playback_notice.show()

    def decide_policy(self, _view, decision, kind):
        if kind in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            action = decision.get_navigation_action()
            uri = action.get_request().get_uri()
            if uri == "about:blank" or supported_uri(uri):
                if hasattr(decision, "use_with_policies"):
                    policy = WebKit2.AutoplayPolicy.ALLOW if is_music_uri(uri) else WebKit2.AutoplayPolicy.DENY
                    decision.use_with_policies(WebKit2.WebsitePolicies(autoplay=policy))
                    return True
                return False
            decision.ignore()
            if action.is_user_gesture():
                self.message("此链接需要其他客户端", "请继续使用网页中的播放或登录入口。")
            return True
        if kind == WebKit2.PolicyDecisionType.RESPONSE:
            response = decision.get_response()
            if is_player_uri(response.get_uri()):
                if 300 <= response.get_status_code() < 400:
                    return False
                if (response.get_mime_type() in ("text/html", "application/xhtml+xml")
                        and 200 <= response.get_status_code() < 300):
                    # Render the entry document even if a server adds
                    # Content-Disposition: attachment to an HTML response.
                    decision.use()
                else:
                    decision.ignore()
                    self.show_error(page_response_error(response))
                return True
            if decision.is_mime_type_supported():
                return False
            # WebKitGTK before 2.40 does not expose the main-resource check.
            # Leave its default handling in place instead of guessing from URI.
            if not hasattr(decision, "is_main_frame_main_resource"):
                return False
            if decision.is_main_frame_main_resource():
                decision.download()
                return True
        return False

    def create_popup(self, view, _action):
        popup = MusicWindow(self.app, related_view=view)
        self.app.watch_login_window(popup)
        popup.set_transient_for(self)
        return popup.webview

    def permission_request(self, _view, request):
        request.deny()
        return True

    def enter_fullscreen(self, *_):
        self.fullscreen()
        self.window_controls.hide()
        self.update_window_interaction(Gdk.WindowState.FULLSCREEN)
        return True

    def leave_fullscreen(self, *_):
        self.unfullscreen()
        self.window_controls.show()
        return True

    def message(self, title, details):
        dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                                   message_type=Gtk.MessageType.INFO,
                                   buttons=Gtk.ButtonsType.CLOSE, text=title)
        dialog.format_secondary_text(details)
        dialog.run()
        dialog.destroy()

    def about(self, *_):
        self.message("网易云音乐 · 独立桌面版 " + VERSION,
                     "使用 GTK 3 与 WebKitGTK 运行网易云音乐网页。\n"
                     "无需安装或启动 Chrome、Chromium 或 Electron。\n"
                     "这是非官方桌面封装，音乐、账号和服务由网易云音乐提供。\n\n"
                     "登录数据保存在本应用的独立目录中。关闭窗口将停止播放。")


def main():
    parser = argparse.ArgumentParser(description="网易云音乐独立 WebKitGTK 桌面应用")
    parser.add_argument("--version", action="version", version=VERSION)
    parser.add_argument("--check", action="store_true", help="检查运行依赖，不打开窗口")
    args = parser.parse_args()
    if args.check:
        print(f"应用 {VERSION}; Python {sys.version.split()[0]}; "
              f"GTK {Gtk.MAJOR_VERSION}.{Gtk.MINOR_VERSION}.{Gtk.MICRO_VERSION}; "
              f"WebKitGTK {WebKit2.get_major_version()}.{WebKit2.get_minor_version()}.{WebKit2.get_micro_version()} (API {WEBKIT_API})")
        api = "evaluate_javascript" if hasattr(WebKit2.WebView, "evaluate_javascript") else "run_javascript"
        print(f"JavaScript 接口：{api}; 桌面会话：{os.environ.get('XDG_SESSION_TYPE', '未设置')}; "
              f"显示后端：{os.environ.get('GDK_BACKEND', '自动')}")
        print("网络方式：直连")
        return 0
    os.umask(0o077)
    app = MusicApplication()
    try:
        return app.run([sys.argv[0]])
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
